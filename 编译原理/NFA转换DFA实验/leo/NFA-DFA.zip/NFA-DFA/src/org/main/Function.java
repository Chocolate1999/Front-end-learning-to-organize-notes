package org.main;

import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

public class Function {
	
	private  Scanner scan = new Scanner(System.in);
	private  StringBuffer node = new StringBuffer();
	
	public  Vector<Edge> edgeInPut(){          //���������
		
		
		Vector<Edge> vect = new Vector<Edge>();
		StringBuffer str = new StringBuffer();
		System.out.println("����������ߵ���Ϣ����");
		System.out.println("��ת���ַ�Ϊ�� �� ��#�� ��ʾ ����$����ʾ�������롿");
		while(scan.hasNextLine()) {
			Edge edge = new Edge();
			str.replace(0, str.length(), scan.nextLine());
			if(str.charAt(0)=='$')
				break;
			edge.setBeforeNode(str.toString().substring(0,str.indexOf(" ")));
			edge.setTchar(str.toString().substring(str.indexOf(" ")+1,str.lastIndexOf(" ")).charAt(0));
			edge.setNextNode(str.toString().substring(str.lastIndexOf(" ")+1));
			if(!Conversion.connector.toString().contains(String.valueOf(edge.getTchar()))) {
				Conversion.connector.append(edge.getTchar());
			}
			if(!this.node.toString().contains(String.valueOf(edge.getBeforeNode())) ){
				this.node.append(edge.getBeforeNode());
			}
			if(!this.node.toString().contains(String.valueOf(edge.getNextNode()))) {
				this.node.append(edge.getNextNode());
			}
			vect.add(edge);
		}
		
		return vect;
	}
	
	public void pointInPut() {//��ʼ����ֹ�ڵ�����
		System.out.println("����������ʼ�ڵ����Ϣ����");
		while(scan.hasNextLine()) {
			char beginchar = scan.nextLine().charAt(0);
			String endNode;
			while(!this.node.toString().contains(String.valueOf(beginchar))) {
				System.out.println("����ʼ�ڵ��������������롿��");
				beginchar = scan.nextLine().charAt(0);
			}
			Conversion.beginNode = beginchar;
			System.out.println("����������ֹ�ڵ����Ϣ����");
			endNode = scan.nextLine();
			while(!this.node.toString().contains(endNode)){
				System.out.println("����ֹ�ڵ��������������롿��");
				endNode = scan.nextLine();
			}
			
			Conversion.endNode += endNode;
			break;
		}
		
	}
	
	
	public  Set<String> getEClosure(Vector<Edge> edges ,Set<String> desk ) {    //�õ��հ�
		Vector<String> vector = new Vector<String>(desk);
		
		for(int i = 0;i<vector.size();i++){//��vector����
			for(int j=0; j<edges.size();j++) {
				if((vector.get(i).equals(edges.get(j).getBeforeNode())) && edges.get(j).getTchar() == '#') {  //
					vector.add(edges.get(j).getNextNode());
				}
			}
		}
		Set<String> set = new TreeSet<String>();
		for(String str : vector) {
			set.add(str);
		}
		return set;
	}

	public  Set<String> move(char ttchar,Vector<Edge> edges ,Set<String> desk) {
		Vector<String> vector = new Vector<String>();
		Iterator<String> iter = desk.iterator();
		while(iter.hasNext()) {
			String str = iter.next();
			for(int j=0; j<edges.size();j++) {
				if(( str.equals(edges.get(j).getBeforeNode() ))&& (edges.get(j).getTchar() == ttchar)) {
					vector.add(edges.get(j).getNextNode());
				}
			}
		}
		Set<String> set = new TreeSet<String>();
		for(String str : vector) {
			set.add(str);
		}
		return set;
	}
	
	public void outPut() {
		Conversion conversion = new Conversion();
		conversion.subsetting();
		Set<Relation> set = conversion.getRelaVec();
		Map<Character,Set<String>> map = conversion.getStateSet();
		Iterator<Relation> iterSet = set.iterator();
		System.out.println("��****�Ӽ�ת����ϵ****����");
		while(iterSet.hasNext()) {
			Relation relation = iterSet.next();
			System.out.print(relation.getBeginGather() + "-- ��");
			System.out.print(relation.getRthar() + "�� -->");
			System.out.println(relation.getNextGather());
		}
		System.out.println("��****��������Ӽ�****����");
		for(char i='A';i<'A'+map.size();i++) {
			System.out.println(i+":  "+map.get(i));
		}
		System.out.println("��****��̬****����");
		for(char i='A';i<'A'+map.size();i++) {
			for(String str: map.get(i) ) {
			if(str.equals(Conversion.endNode)) {
				System.out.println(i+":  "+map.get(i));
				break;
				}
			}
			
		}
		
	}
	

}
