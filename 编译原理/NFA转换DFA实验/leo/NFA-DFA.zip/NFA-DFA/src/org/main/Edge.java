package org.main;



public class Edge {
	
	private String beforeNode;// ǰ�ڵ�
	private String nextNode;//��ڵ�
	private char tchar;//ת���ַ�
	
	public String getBeforeNode() {
		return beforeNode;
	}
	public void setBeforeNode(String beforeNode) {
		this.beforeNode = beforeNode;
	}
	public String getNextNode() {
		return nextNode;
	}
	public void setNextNode(String nextNode) {
		this.nextNode = nextNode;
	}
	public char getTchar() {
		return tchar;
	}
	public void setTchar(char tchar) {
		this.tchar = tchar;
	}
	
}
