package org.main;

import java.util.Set;

public class Relation { //����֮���ת����ϵ
	
	private Set<String> beginGather;//ǰ�ڵ�
	private char rthar;//ת���ַ�
	private Set<String> nextGather;//��ڵ�
	
	public Relation() {
		
	}
	
	public Relation(Set<String> beginGather,char rthar,Set<String> nextGather) {
		this.beginGather = beginGather;
		this.rthar = rthar;
		this.nextGather = nextGather;
	}

	public Set<String> getBeginGather() {
		return beginGather;
	}

	public void setBeginGather(Set<String> beginGather) {
		this.beginGather = beginGather;
	}

	public char getRthar() {
		return rthar;
	}

	public void setRthar(char rthar) {
		this.rthar = rthar;
	}

	public Set<String> getNextGather() {
		return nextGather;
	}

	public void setNextGather(Set<String> nextGather) {
		this.nextGather = nextGather;
	}


}
